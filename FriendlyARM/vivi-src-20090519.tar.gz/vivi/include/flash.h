#ifndef __FLASH_H__
#define __FALSH_H__

extern unsigned long flash_base_addr;

#endif /* __FALSH_H__ */
