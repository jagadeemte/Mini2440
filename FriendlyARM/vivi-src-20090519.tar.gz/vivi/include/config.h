/* rough config.h */

/*
 * History
 *
 * 2002-01-16: Nandy Lyu <nandy@mizi.com>
 *    - Initial code
 *
 */

#ifndef _CONFIG_H_
#define _CONFIG_H_

#include "autoconf.h"

#endif /* _CONFIG_H_ */
